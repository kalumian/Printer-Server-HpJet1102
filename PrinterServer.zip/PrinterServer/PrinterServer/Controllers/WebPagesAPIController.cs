﻿using Microsoft.AspNetCore.Mvc;
using System.Drawing.Printing;

namespace PrinterServer.Controllers
{
    [Route("printer-server")]
    [ApiController]
    public class WebPagesAPIController : ControllerBase
    {
        private string PrinterName = "HP LaserJet Professional P1102";

        [HttpGet]
        public ContentResult GetHomePage()
        {
            string HtmlContent = "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><title>HP Jet 1102p</title><style>body{font-family:Arial,sans-serif;background-color:#f4f4f4;margin:0;padding:0}.container{max-width:800px;margin:20px auto;padding:20px;background:#fff;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.1)}h1{text-align:center;color:#333}.form-group{margin-bottom:15px}label{display:block;font-weight:bold;margin-bottom:5px}input[type=\"file\"]{display:block;width:100%}button{background-color:#007bff;border:none;color:white;padding:10px 20px;text-align:center;text-decoration:none;display:inline-block;font-size:16px;margin:10px 2px;cursor:pointer;border-radius:4px}button:disabled{background-color:#cccccc;cursor:not-allowed}.status{margin-top:15px;text-align:center}.status p{font-size:18px;color:#333}</style></head><body><div class=\"container\"><h1>Remote Printing with HP LaserJet 1102</h1><div class=\"form-group\"><label for=\"fileUpload\">Upload File (PDF, JPG, JPEG, PNG):</label><input type=\"file\" id=\"fileUpload\" accept=\".pdf, .jpg, .jpeg, .png\"></div><button id=\"printButton\" disabled>Print File</button><div class=\"status\" id=\"statusMessage\"></div></div><script>const fileInput=document.getElementById('fileUpload');const printButton=document.getElementById('printButton');const statusMessage=document.getElementById('statusMessage');fileInput.addEventListener('change',function(){const file=fileInput.files[0];if(file){const validTypes=['pdf','jpg','jpeg','png'];const fileType=file.name.split('.').pop().toLowerCase();const fileSizeMB=(file.size/(1024*1024)).toFixed(2);if(validTypes.includes(fileType)){statusMessage.innerHTML=`<p>File selected: ${file.name} (${fileSizeMB} MB)</p>`;printButton.disabled=false}else{statusMessage.innerHTML=`<p style=\"color: red;\">Invalid file type. Please upload a PDF or an image (JPG, JPEG, PNG).</p>`;printButton.disabled=true}}else{statusMessage.innerHTML='';printButton.disabled=true}});printButton.addEventListener('click',function(){const file=fileInput.files[0];if(file){const formData=new FormData();formData.append('file',file);fetch('http://192.168.8.105:5000/printer-server/Print',{method:'POST',body:formData}).then(response=>response.text()).then(data=>{statusMessage.innerHTML=`<p style=\"color: green;\">${data}</p>`}).catch(error=>{statusMessage.innerHTML=`<p style=\"color: red;\">An error occurred: ${error.message}</p>`})}});</script></body></html>\r\n";
            return Content(HtmlContent, "text/html");
        }

        [HttpPost("Print")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UploadAndPrint(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("No file uploaded.");
            }

            try
            {
                // Define the folder for storing uploaded files
                string folderOfResource = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "PrintServer");
                if (!Directory.Exists(folderOfResource))
                {
                    Directory.CreateDirectory(folderOfResource);
                }

                string extension = Path.GetExtension(file.FileName).ToLower();
                string dateStamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string fileName = $"{dateStamp}_{Guid.NewGuid()}{extension}";
                string newFilePath = Path.Combine(folderOfResource, fileName);

                // Save the uploaded file
                using (var stream = new FileStream(newFilePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                if (extension == ".pdf")
                {
                    using (var pdfDocument = PdfiumViewer.PdfDocument.Load(newFilePath))
                    {
                        // Setup print document
                        PrintDocument printDoc = new PrintDocument();
                        printDoc.PrinterSettings.PrinterName = "HP LaserJet Professional P1102";

                        printDoc.PrintPage += (sender, e) =>
                        {
                            int pageNumber = 0; // Print the first page (0-based index)

                            using (var pdfPage = pdfDocument.Render(pageNumber, e.PageBounds.Width, e.PageBounds.Height, 96, 96, true))
                            {
                                e.Graphics.DrawImage(pdfPage, e.PageBounds);
                            }
                        };

                        // Start printing
                        printDoc.Print();
                    }
                }
                else if (extension == ".jpg" || extension == ".png" || extension == ".jpeg")
                {
                    if (!System.IO.File.Exists(newFilePath))
                    {
                        return BadRequest($"File not found: {newFilePath}");

                    }

                    using (var image = System.Drawing.Image.FromFile(newFilePath))
                    {
                        PrintDocument printDoc = new PrintDocument();
                        printDoc.PrinterSettings.PrinterName = "HP LaserJet Professional P1102";

                        printDoc.DefaultPageSettings.PaperSize = new PaperSize("A4", 827, 1169); // A4 size in hundredths of an inch

                        printDoc.PrintPage += (sender, e) =>
                        {
                            // Get the bounds of the page
                            System.Drawing.Rectangle pageBounds = e.PageBounds; // Use System.Drawing.Rectangle

                            // Calculate the scaling factor to fit the image within the page bounds
                            float xScale = pageBounds.Width / (float)image.Width;
                            float yScale = pageBounds.Height / (float)image.Height;
                            float scale = Math.Min(xScale, yScale);

                            // Calculate the position to center the image
                            float xPos = (pageBounds.Width - image.Width * scale) / 2;
                            float yPos = (pageBounds.Height - image.Height * scale) / 2;

                            // Draw the image on the page
                            e.Graphics.DrawImage(image, xPos, yPos, image.Width * scale, image.Height * scale);
                        };

                        // Start printing
                        printDoc.Print();

                    }
                }
                else
                {
                    return BadRequest("Unsupported file type.");
                }

                return Ok("The document was printed successfully.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred: " + ex.Message);
            }
        }

    }
}
